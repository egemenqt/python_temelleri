hesaps=[]
import random
import datetime
import termcolor
while True:
    try:
        while True:
            try:
                while True:
                    now=datetime.datetime.now()
                    #kayıt işlemi-----------------------------------------------------------------------------
                    usersign=int(input("*****YİĞİT HOLDİNG TİC.A.Ş******\nhoşgeldiniz\nkayıt ol 1)\ngiriş 2)\nçıkış 3)\nyapmak istediğiniz:"))
                    if(usersign==1):
                        username=input("isminizi giriniz:".capitalize().strip())
                        usersurname=input("soy isminizi giriniz:".capitalize().strip())
                        usertc=int(input("(6 haneli)tc no giriniz:"))
                        userphoneno=int(input("telefon numaranızı giriniz:"))
                        userkayitpara=float(input("hesabınızın açılması için en az 50 TL yatırınız:"))
                        if(userkayitpara<50):
                            print("lütfen en az 50 TL yatırınız.")
                        else:
                            nuserhesapno=random.randint(100000,999999)
                            nuserpsw=random.randint(1000,9999)
                            krediborc=0
                            hesaps.append({"ad":username,"soyad":usersurname,"tc no":usertc,"telefon numarası":userphoneno,"bakiye":userkayitpara,"hesap no":nuserhesapno,"hesap şifre":nuserpsw,"kredi borc":krediborc})
                            print(termcolor.colored("{} {} kaydınız başarılı şekilde yapılmıştır.\nhesap numaranız:{}\nşifreniz:{}".format(username.capitalize(),usersurname.capitalize(),nuserhesapno,nuserpsw),on_color="on_green",color="grey"))
                    if(usersign==2):
                #user giriş---------------------------------------------------------------------------------
                        usersignhpno=int(input("hesaps numaranızı giriniz:"))
                        usersignpsw=int(input("şifrenizi giriniz:"))
                        for hesap in hesaps:
                            if(usersignhpno!=hesap["hesap no"] and usersignpsw!=hesap["hesap şifre"]):
                    #user işlem---------------------------------------------------------------------------------------
                                print(termcolor.colored("hesap no veya şifre hatalı!",color="red",attrs=["bold"]))
                            else:    
                                while True:
                                    usersec=int(input("hoşgeldiniz\npara çek 1)\n---------\npara yatır 2)\n---------\nhesap bilgileri 3)\n-------\nkredi çek 4)\n---------\nhavale 5)\n-------\nkredi borcu yatır 6)\nçıkış 7)\ngiriş kaydedildi:{s}\nişlem:".format(s=now)))
                    #user para çekme------------------------------------------------------------------------------------                
                                    if(usersec==1):
                                        paracek=float(input("çekmek istediğiniz miktar nedir:"))
                                        def parausercek():
                                            a=hesap["bakiye"] - paracek
                                            x=hesap.items()
                                            hesap["bakiye"]=a
                                            return x
                                        print(f"yeni bakiyeniz:{parausercek()}")
                    #user para yatirma-----------------------------------------------------------------------                
                                    elif(usersec==2):
                                        parayatiruser=float(input("yatırmak istediğiniz miktar nedir:"))
                                        def parayatir():
                                            a=hesap["bakiye"] + parayatiruser
                                            x=hesap.items()
                                            hesap["bakiye"]=a
                                            return x
                                        print(f"yeni bakiyeniz:{parayatir()}")
                    #user hesaps bilgisi----------------------------------------------------------------
                                    elif(usersec==3):
                                        print(hesap)
                    #user kredi çekme----------------------------------------------------------------
                                    elif(usersec==4):
                                        print("50.000 ile 99.999 arası %25 faiz\n100.000 ile 399.999 arası %50 faiz\n400.000 ile 699.999 arası %75 faiz\n700.000+ %100 faiz")
                                        krediuserwant=float(input("çekmek istediğiniz miktar nedir:"))
                                        if(50000<=krediuserwant<=99999):
                                            def kredi1():
                                                x=hesap["kredi borc"] + krediuserwant*1.25
                                                a=hesap.update({"kredi borc":x})
                                                return a
                                            hesaps.append({"kredi borc":kredi1()})
                                            print(f"kredi borcunuz:{kredi1()}")
                                            print(termcolor.colored("{} TL başarılı şekilde çekilmiştir borcunuzu hesaps bilgillerimden görebilirsiniz\niyi günlerde kullanın.".format(krediuserwant),on_color="on_green"))
                                        if(100000<=krediuserwant<=399999):
                                            def kredi2():
                                                x=hesap["kredi borc"] + krediuserwant*1.5
                                                a=hesap.update({"kredi borc":x})
                                                return a
                                            hesaps.append({"kredi borc":kredi2()})
                                            print(f"kredi borcunuz:{kredi2()}")
                                            print(termcolor.colored("{} TL başarılı şekilde çekilmiştir borcunuzu hesaps bilgillerimden görebilirsiniz\niyi günlerde kullanın.".format(krediuserwant),on_color="on_green"))
                                        if(400000<=krediuserwant<=699999):
                                            def kredi3():
                                                x=hesap["kredi borc"] + krediuserwant*1.75
                                                a=hesap.update({"kredi borc":x})
                                                return a
                                            hesaps.append({"kredi borc":kredi3()})
                                            print(f"kredi borcunuz:{kredi3()}")
                                            print(termcolor.colored("{} TL başarılı şekilde çekilmiştir borcunuzu hesaps bilgillerimden görebilirsiniz\niyi günlerde kullanın.".format(krediuserwant),on_color="on_green"))
                                        if(700000<=krediuserwant):
                                            def kredi4():
                                                x=hesap["kredi borc"] + krediuserwant*2
                                                a=hesap.update({"kredi borc":x})
                                                return a
                                            hesaps.append({"kredi borc":kredi4()})
                                            print(f"kredi borcunuz:{kredi4()}")
                                            print(termcolor.colored("{} TL başarılı şekilde çekilmiştir borcunuzu hesaps bilgillerimden görebilirsiniz\niyi günlerde kullanın.".format(krediuserwant),on_color="on_green"))
                    #user havale-----------------------------------------------------------------------------------------                        
                                    elif(usersec==5):
                                        havalehpno=int(input("havale yapılacak kişinin hesap no'nu giriniz:"))
                                        if(havalehpno!=hesap["hesap no"]):
                                            print("hatalı hesap no")
                                        else:
                                            havaleyatir=float(input("yatırmak istediğiniz miktar nedir:"))
                                            result = havaleyatir + hesap["bakiye"]
                                            hesap.update({"bakiye":result})
                                            print("ismi {}olan {} no'lu kişinin banka hesabına {}TL gönderilmiştir".format(hesap["ad"],havalehpno,result))
                    #user finito-------------------------------------------------------------------------------------                        
                                    elif(usersec==6):
                                        x=int(input("yatırmak istediğiniz miktar:"))
                                        a=hesap["kredi borc"] - x
                                        hesap.update({"kredi borcunuz":a})
                                    elif(usersec==7):
                                        print("iyi günler dileriz.")
                                        break
                        break
                    elif(usersign==3):
                            print("iyi günler dileriz.")
                            break
                    else:
                        raise KeyError(termcolor.colored("sadece ekranda görüğünüz sayıları girebilirsiniz.",on_color="on_red"))
            except ValueError as e:
                    print(termcolor.colored("lütfen size belirtilen sayısal değer girin",on_color="on_red",attrs=["bold"]))
                    print(termcolor.colored(f"hata:{e}",on_color="on_red",attrs=["bold"]))
            else:
                break  
    except:
        print(termcolor.colored("bilinmeyen hata",color="red"))
        
    break