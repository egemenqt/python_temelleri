#str and repr      
#magic metodlar özel gömülü metodlardır __method__ şeklinde kullanılır
'''from datetime import *
today = date.today()
print(today)            #
print(str(today))
print(repr(today))      #repr geliştirici için kullanılır 
'''
class User:
    def __init__(self,name,age):
        self.name=name
        self.age=age
        # return f"{self.name} {self.ag}"       eğer soldaki gibi yazarsan type eror verir python bunu okuyamaz

    def __str__(self):                          #soldaki gibi __str__(self): tanımlaman lazım
        return f"ad:{self.name} yaş:{self.age}" 

    def __repr__(self):                         #repr developer için bilgi verir
        return "repr working"
            
user1=User("std",40)
print(user1)
print(repr(user1))

