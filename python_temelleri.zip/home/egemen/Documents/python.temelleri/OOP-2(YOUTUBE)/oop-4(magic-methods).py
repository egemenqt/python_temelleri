# #MATH DUNDER METHODS
# # __add__(self, anotherObj) for + operator.
# # __sub__(self, anotherObj) for – operation on object.
# # __mul__(self, anotherObj) for * operation on object.
# # __matmul__(self, anotherObj) for @ operator (numpy matrix multiplication).
# # __truediv__(self, anotherObj) for simple / division operation on object.
# # __floordiv__(self, anotherObj) for // floor division operation on object.
# class Mylist(list):     #dunder listten miras alır
#     def __add__(self,other):
#         if len(self)!=len(other):
#             return  "toplanamaz index eşit değil"
#         else:
#             rs=Mylist()
#             for i in range(len(other)):         
#                 rs.append(self[i]+other[i])         
#         return rs
#     def __sub__(self,other):
#         if len(self)!=len(other):
#             return  "toplanamaz index eşit değil"
#         else:
#             rs=Mylist()
#             for i in range(len(other)):
#                 rs.append(self[i]-other[i])
#         return rs
#     def __eq__(self,other):
#         if sum(self)==sum(other):       #sum liste index toplamı metodu
#             return True
#         else:
#             return False
# mylist1=Mylist([1,2,3])        
# mylist2=Mylist([4,5,6])
# print(mylist1 + mylist2)        #liste içindeki index numara sırası ile yopladık
# print(mylist1 - mylist2)
# print(mylist1==mylist2)