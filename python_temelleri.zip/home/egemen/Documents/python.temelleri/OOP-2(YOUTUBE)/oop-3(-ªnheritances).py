class Worker:

    zam_orani=1.1
    def __init__(self,name,surname,maas):
        self.name=name
        self.surname=surname
        self.maas=maas
        self.email=name + surname + "@psplus.onion"

    def  show_info(self):
        return f"ad:{self.name}\nsoyad:{self.surname}\nmaaş:{self.maas}\nemail:{self.email}"

u1=Worker("stdk","std",19)
u2=Worker("egemen","yigit",25)
print(u1.email)

class Developer(Worker):        #burada yeni class oluştururken içine miras atamak zorundasın
    zam_orani=1.2               #eğerki burada zam oranını 1.2 tanımlarsan miras aldığın yeri döndürmez yazdığın yeri döndürür
    def show_info(self):
        return f"ad:{self.name}\nsoyad:{self.surname}\nmaaş:{self.maas}\nemail:{self.email}"
        return "hello world"     #show_info(self) fonksiyonunu burada ilk atadığın için burayı parametre alır mirasa gitmez
    def __init__(self, name, surname, maas):
        super().__init__(name, surname, maas)   #super().fonk adi ile miras aldığın fonk burada direk tanımlayabilirsin
dev1=Developer("samet","ayaz",21)  
print(dev1.email)      #soldaki kısımda ilk başta Developer kısmına bakar info yok ise miras aldığı kısma bakar
print(dev1.show_info())
