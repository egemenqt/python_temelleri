#sınıf ve örnek kavramları(class and instance)
#class oluşturma                                    !!!!en önemli yerdir
#özelllik ve metodlar(attributes and methods)
class Worker:
    zam_ori=1.1
    def __init__(self,name,surname,age,maas):
        #self.name/self.x attributes
        self.name=name
        self.surname=surname
        self.age=age
        self.maas=maas
    def maas_zam(self):
        self.maas=self.maas*Worker.zam_ori
        return f"yeni maas:{self.maas}"
    def show_info(self):
        return f"ad:{self.name} soyad:{self.surname} yaş:{self.age} {Worker.maas_zam(self)}"
w1=Worker("ege","yg",19,5000)        #object
w2=Worker("std","bg",19,6000)
# print(w1.show_info())
# print(w2.show_info())
# print(w1.__dict__)      #dictionary import eder
# print(w2.__dict__)
# w1.zam_ori=1.2          #eğer object içinde yoksa class içine bakar
# w2.zam_ori=1.1           #değişiklik sadece nesne için geçerlidir
print(w1.__dict__)
print(w2.__dict__)
print(w1.show_info())
print(w1.show_info())
