class Worker:

    zam_orani=1.1
    def __init__(self,name,surname,maas):
        self.name=name
        self.surname=surname
        self.maas=maas
        self.email=name + surname + "@psplus.onion"


    def  show_info(self):
        return f"ad:{self.name}\nsoyad:{self.surname}\nmaaş:{self.maas}\nemail:{self.email}"


u1=Worker("klsa","std",19)
u2=Worker("egemen","yigit",25)
print(u1.email)


class Developer(Worker):        #burada yeni class oluştururken içine miras atamak zorundasın
    zam_orani=1.2               #eğerki burada zam oranını 1.2 tanımlarsan miras aldığın yeri döndürmez yazdığın yeri döndürür
    def show_info(self):
        return f"ad:{self.name}\nsoyad:{self.surname}\nmaaş:{self.maas}\nemail:{self.email}"
        return "hello world"     #show_info(self) fonksiyonunu burada ilk atadığın için burayı parametre alır mirasa gitmez
    def __init__(self, name, surname, maas):
        super().__init__(name, surname, maas)   #super().fonk adi ile miras aldığın fonk burada direk tanımlayabilirsin


dev1=Developer("samet","ayaz",21)  
print(dev1.email)      #soldaki kısımda ilk başta Developer kısmına bakar info yok ise miras aldığı kısma bakar
print(dev1.show_info())


class Admin(Worker):

    def __init__(self, name, surname, maas,workers=None):
        super().__init__(name, surname, maas)
        if workers==None:
            self.workers=[]
        else:
            self.worker=workers
    
    def remove_workers(self,workerinstance):
        if workerinstance in self.workers:
            self.workers.remove(workerinstance)
            
    def append_workers(self,workerinstance):
        if workerinstance not in self.workers:
            self.workers.append(workerinstance)
    @classmethod
    def __repr__(cls):
        return  f"ad:{cls.append_workers()}     soyad:{cls.append_workers()}       maaş:{cls.append_workers()}"
    

admin1=Admin("ali","koç",50000)
admin1.append_workers(u1)
admin1.append_workers(u2)
admin1.append_workers(dev1)
print(admin1.__repr__)