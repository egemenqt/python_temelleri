#object methods
#class methods
from datetime import *
class User:
    zam_orani=1.1   #class variables
    user_numbs=0
    def __init__(self,name,age):        #parametre olarak selfin kendisini alır
        self.name=name
        self.age=age
        User.user_numbs+=1
        
    def said_info(self):        #instance method class içinde fonk oluşturmadır
        return f"ad:{self.name}  yaş:{self.age}   "

    @classmethod            #parametre olarak cls kendisini alır
    def said_user_numbs(cls):
        return cls.user_numbs

    @classmethod
    def str_with(cls,str_):
        name,age=str_.split("-")
        return cls(name,age)

    @classmethod
    def yearofbirth(cls,name,year_birth):
        return cls(name,datetime.now().year - year_birth)

    @staticmethod           #parametre olarak istediğimizi atarız 
    def dog_yil(name,age):
        return f"{name,datetime.now().year - age}"

# u1=User("nesli",19)
u2=User("egemen",19)
# print(u1.said_info())
u3=User.str_with("samet-20")
print(User.said_user_numbs()) 
print(u3.said_info())
u4 = User.yearofbirth("enes",1998)
print(u4.said_info())
print(User.said_user_numbs())
u5=User.dog_yil("gökselin",25)
print(u5)