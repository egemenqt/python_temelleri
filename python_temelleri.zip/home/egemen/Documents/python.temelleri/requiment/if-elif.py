x = int(input("bir sayı giriniz: "))
if (x>0):
    print(f"{x} sayısı pozitif bir sayıdır")
elif (x==0):
    print("sayı sıfıra eşittir")
else:
        print(f"{x} sayısı negatif bir sayıdır.")
        
y= int(input("bir sayı giriniz: "))
if (y%2==0):
    print("{}    sayısı çift sayıdır.".format(y))
else:
    print("{}  sayısı tek sayıdır".format(y))