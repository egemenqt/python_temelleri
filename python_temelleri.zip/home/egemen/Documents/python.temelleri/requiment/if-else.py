usnm = input("kullanıcı adınızı giriniz:  ")# if else doğrumu doğruysa şunu yap yanlışsa bunu yap şeklinde kullanılır
pswrd  = input("şifrenizi giriniz:  ")      # if else soldaki gibi kullanılır iç içe if else yapılabilir
if (usnm=="egemen.y"):
    if (pswrd=="1234"):
        print(f"hoşgeldin: {usnm} ")
    else:
            print("şifre hatalı!")
else:
    print("kullanıcı adı hatalı! ahahahahah")
if (usnm!= "egemen.y") and (pswrd != "1234"):
    print("kullanıcı adı ve şifre hatalı!")
