'''username = input("isminizi ekrana giriniz:  ".lower().strip())
userage = int(input("yaşınızı giriniz: "))
usereducatıon = input("eğitim düzeyiniz nedir: ".lower().strip())
if (userage>=18) and ((usereducatıon.lower().strip()=="lise") or (usereducatıon.lower().strip()=="üniversite")):
    print("ehliyet almaya hak kazandınız.")
elif(userage<=18):
    print("yaşınız ehliyet almaya yetmiyor.")
elif(usereducatıon!="lise") or (usereducatıon!="üniversite"):
    print("eğitim seviyeniz ehliyet almaya yetmiyor.")'''
#-----------------------------------------------------------------------------------------------------------------------------
'''not1=float(input("1. notunuzu giriniz:  "))
not2=float(input("2.notunuzu giriniz:  "))
sozlu = float(input("sözlü notunuzu giriniz: "))
avarage = (not1+not2+sozlu)/3
if (0<=avarage<=24):
    print("karne notu: 0" )
if (25<=avarage<=44):
    print("karne notu:  1")
if(45<=avarage<=54):
    print("karne notu: 2")
if(55<=avarage<=69):
    print("karne notu: 3")
if(70<=avarage<=84):
    print("karne notu: 4")
if(85<=avarage<=100):
    print("karne notu: 5")'''
#-----------------------------------------------------------------------------------------------------------------------------
import datetime             #bu ifade suanki zamanı termınale yazdırır
suan = datetime.datetime.now()
print(suan)
