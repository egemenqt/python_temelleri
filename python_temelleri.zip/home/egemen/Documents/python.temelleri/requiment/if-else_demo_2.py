dızelprıce = 24.90
benzınprıce = 21.50
yakıttıp = input("yakıt tipinizi giriniz: ")
if (yakıttıp=="dizel") or (yakıttıp=="benzin"):
    if (yakıttıp=="benzin"):
        ortkmb = float(input("100 km de kaç litre benzin yakıyor: "))
        mesafe=float(input("yolculuğunuz kaç km: "))
        rs = (ortkmb/100)*benzınprıce*mesafe
        print(f"ortalama masraf : {rs.__round__(2)} TL")
    if ( yakıttıp=="dizel"):
            ortkmd = float(input("100 kmde kaç litre dizel yakıyor: "))
            mesafe2=float(input("yolculuğunuz kaç km "))
            rs2 = (ortkmd/100)*dızelprıce*mesafe2
            print(f"ortalama masraf  {rs2.__round__(2)} TL")

else:
    print("yakıt tipi tanınamadı.")