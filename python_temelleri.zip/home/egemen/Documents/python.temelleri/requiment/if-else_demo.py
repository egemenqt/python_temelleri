'''vz1 = float(input("1.vize notunuzu giriniz:  "))
vz2 = float(input("2.vize notunuzu giriniz:  "))
fnl = float(input("final notunuzu giriniz:  "))
rs = ((vz1+vz2)/2)*0.6 + fnl*0.4
if (fnl>=70):
    print("öğrenci geçti.")
else:
    if (fnl>=50) and (rs>=50):
        print(f"{rs}  ortalamalı öğrenci geçti")
    else:
        print(f"{rs} ortalamalı öğrenci kaldı.")'''
#-------------------------------------------------------------------------------------------,
weıght = float(input("kilonuzu giriniz:  "))
lenght = float(input("boyunuzu giriniz: "))
wlı = weıght/(lenght**2)
if (0<=wlı<=18.4):
    print("dünya standartlarına göre zayifsiniz./ boy kilo indexiniz:  {}".format(wlı))
elif (18.5<=wlı<=24.5):
    print("dünya standartlarına göre normalsiniz./ boy kilo indexsiniz:  {}".format(wlı))
elif(25<=wlı<=29.9):
    print("dünya standartlarına göre fazla kilolusunuz/ boy kilo indexsiniz:  {}".format(wlı))
