'''numbsl = [10,20,30,40,50]
def total(numbs):
    result = 0
    for i in numbsl:
        result+=i
    return result
print(total(numbsl))            '''
# args ifadesi yukarıda numbs1 in içine tanımlaman yerine kendi liste oluşturur aşağıdaki gibi kullanılır
def total(*args):
    result=0
    for i in args:
        result+=i
    return result               #return etmezsen outputta none yazar
print(total(10,20,30,40))       #args ifadesi görüldüğü gibi işe yarar
