# return komutu atanan değeri döndürür  aşağıdaki gibi kullanılır ve genellikle fonk. içinde kullanılır
'''def total():
    a=10
    b=20
    return (a+b)
total()'''
#----------------------------------------------------------------
# import datetime
# simdiyıl   =  datetime.datetime.now().year
# def yashesap():
#     return simdiyıl - 2003
# print(yashesap())
def suansaat():
    import datetime
    return datetime.datetime.now().hour
def merhaba():
    if (suansaat()>=19):
        print("iyi akşamlar egemen bey")
    elif(12<=suansaat()<=18):
        print("tünaydın egemen bey") 
    else:
        print("günaydın egemen bey")
merhaba()