def name(firstnm,surnm):
    return f"your name is:{firstnm} {surnm}"
print(name(surnm="yiğit",firstnm="egemen"))
# sırasını bile karıştırsan yukarıdaki tanımlama ile halledebilirsin
