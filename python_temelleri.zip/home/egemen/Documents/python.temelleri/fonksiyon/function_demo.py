'''userkelıme = input("bir kelime girilsin:")
userkackez = int(input("kaç kez ekrana yazdırılsın:"))
i=0
while(i<userkackez):
    i+=1
    print(userkelıme)'''
#----------------------------------
'''def dikal(kısa,uzun):
    (kısa*uzun)
print(dikal(2,3))'''
#------------------------------------------------
'''def dikcev(kısa,uzun):
    return    ((kısa*2)+(uzun*2))
print(dikcev(6,5))'''
#--------------------------------------------------
'''import random
def yazıtura():
    x=random.randint(1,2)
    if(x==1):
        print("yazı")
    else:
        print("tura")
yazıtura()'''
#----------------------------------------------------------------
'''def asalbul(a,b):
    for sayiaralik in range(a,b):
        if (sayiaralik>1):
            for i in range(2,sayiaralik):
                if(sayiaralik)'''
#-------------------------------------------------------------------------
'''def tambolnumb(a):
    numb = []
    for i in range(1,a+1):
        if (a%i==0):
            numb.append(i)
    print(numb)
tambolnumb(17) '''      