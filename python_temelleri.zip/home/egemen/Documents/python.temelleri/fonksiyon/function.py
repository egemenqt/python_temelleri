#def işlemi fonksiyon tanımlamak için kullanılır ve aşağıdaki gibi kullanılır
# fonksiyonlar işlem kalabalığı için daha az satırda kullanışlılık açısından kullanılır

def hi():
    for i in range(10):
        print("Hi")
hi()
a=10
b=50
def total():
    a*b
    print(a*b)
total()
