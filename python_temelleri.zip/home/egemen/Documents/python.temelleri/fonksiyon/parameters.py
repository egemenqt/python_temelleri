# def carpım(a,b):
#     return a*b
# resultl = carpım(10,20)
# resultl = carpım(99,54)
# print(resultl)
userage = int(input("doğum yılınızı giriniz:".lower()))
def yashesapla():
    import datetime
    nowyear = datetime.datetime.now().year
    return    (nowyear - userage)
print("yaşınız:"+str(yashesapla()))