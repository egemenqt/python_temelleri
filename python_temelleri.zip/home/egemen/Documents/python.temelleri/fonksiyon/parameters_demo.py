'''def bigsmall(a,b):
    if(a>b):
        print(f"{a} sayısı {b} sayısından büyük")
    else:
        print(f"{b} sayısı {a} sayısından büyük")
    return bigsmall
bigsmall(78547,59)'''
#----------------------------------------------------------
'''def userınfo(letınf):
    return {letter:letınf.count(letter) for letter in letınf}
result = userınfo("egemen")
print(result)'''

#-------------------------------------------------------
def colors(*args):
    if "blue" in args:
        return True
    else:
        False
    return colors
print(colors("blue","purple","red","orange"))
