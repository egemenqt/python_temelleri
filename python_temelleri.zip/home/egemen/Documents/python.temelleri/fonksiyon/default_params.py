# parametre tanımlama def as(a=2) gibi kullanılır aşağıda örnekleri var
'''def message(nm,msg):
    return "{} {}".format(nm,msg)
print(message("egemen","selam"))'''
#örneğin aşağıdaki gibi yapılabilir
from unittest import result


def message(nm="egemen",msg="selam"):
    return f"{msg}  {nm}"
print(message())
#parametre tanımlarken tanımlasan bile en son aşağı işlemi okuduğundan termınale şağıda yaptığın işlemi verir
def nm(a=5,b=2):
    return f"sayıların toplamı:{a+b}"
print(nm(9,8))          #görüldüğü gibi sona yazdığını hesaplar


'''def carp(a,b):
    return a*b
def bol(a,b):
    return a/b
def ıslem(a,b,fn=carp):
    return fn(a,b)
result = ıslem(8,2,bol)
print(result)'''
    