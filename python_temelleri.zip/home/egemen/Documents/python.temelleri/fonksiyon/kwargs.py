# *args ile **kwargs arasındaki en büyük fark *args =tuple / **kwargs=dictionary olarak saklar
#def a(**kwargs) şeklinde kullanılır
def ınfo(**kwargs):
    for key,value in kwargs.items():
        print(f"{key}: {value}")
        
    return ınfo
(ınfo(username="egemen",emaıl="egemen.y@",country="Turkey"))
def myfunc(a,b,*args,**kwargs):
    print(a)
    print(b)
    print(args)
    print(kwargs)
myfunc(10,20,30,40,50,key1="value1",key2="value2")