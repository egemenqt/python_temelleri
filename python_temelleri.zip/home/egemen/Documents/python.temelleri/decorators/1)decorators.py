
#kapsülleme işlemi-----------------------------------
# def outer(num1):
#     print("outer")

#     def inner(num1):
#         print("inner")
#         return num1 +1
#     num2=inner(num1)
#     print(num1,num2)
# outer(1)

def _factorial(num):
    if num is not int:
        raise TypeError("tam sayı girmelisiniz!!")
    else:
        def _inner(num):
            if num <=1:
                return 1
            return num*(_inner(num-1))

    return _inner(num)

print(_factorial(3.5))


