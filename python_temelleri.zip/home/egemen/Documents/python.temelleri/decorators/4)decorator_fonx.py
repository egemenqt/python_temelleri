def greet_(fn):
    def wrapper_():
        print("selam")
        fn()
        print("çalıştı")
    return wrapper_

@greet_
def gm_():
    print("günaydın")

@greet_
def gn_():
    print("iyi geceler")

gm_()
