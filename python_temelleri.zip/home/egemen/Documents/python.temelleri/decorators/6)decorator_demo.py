import time

def hız_hesaplama_(fn):
    def inner(*args,**kwargs):
        start_time=time.perf_counter()  #zamanı başlatır işlem bitene kadar devam eder aşağıda bitirmen gerekir
        print(f"{fn.__name__} fonksiyonu başladı zaman:{start_time}")
        fn(*args,**kwargs)
        stop_time=time.perf_counter() #zamanı burada durdurur
        gecen_süre=stop_time - start_time
        print(f"{fn.__name__} fonksiyonu durdu zaman:{stop_time} geçen süre:{gecen_süre}  sonuç:{fn(*args,**kwargs)}")

    return inner

@hız_hesaplama_
def hız_toplama_():
    return sum(i for i in range(100000000))

@hız_hesaplama_
def list_hız_toplama_():
    return sum([i for i in range(100000000)])

hız_toplama_()