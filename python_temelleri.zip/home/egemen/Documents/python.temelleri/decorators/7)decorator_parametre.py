def gen_do_twice(calistir):
    def do_twice_(fn):
        def inner_(*args,**kwargs):
            for i in range(calistir):
                    fn(*args,**kwargs)
        return inner_
    return do_twice_


@gen_do_twice(calistir=1)
def greet_():
    print("selam")


@gen_do_twice(calistir=5)
def sebze_():
    print("selam egemen")


greet_()
sebze_()