# # def _sayi(num):
# #     def _us(num2):
# #         return num**num2
# #     return _us

# # sayi=_sayi(3)
# # print(sayi(2))


# def _giris(page):
#     def _yetki(role):
#         if role =="admin":
#             return f"izin verildi {page}"
#         else:
#             return f"erişim reddedildi {page}"
#     return _yetki
# us1=_giris("sayfa")
# print(us1("admin"))




