def log_data_(fn):
    def wrapper(*args, **kwargs):
        print(f"çağrılan fonksiyon ismi:{fn.__name__}") #  (fn.__name__) çağrılan fonksiyonun ismini yazar
        print(f"çağrılan fonksiyonun işlemi:{fn.__doc__}")# çağrılan fonksiyonun işlemini yazdırır
        return fn(*args, **kwargs)
    return wrapper

@log_data_
def email_():
    "email hesabı oluşturur"
    ad=input("adınızı giriniz:")
    print(ad + "@gmail.com")

email_()

