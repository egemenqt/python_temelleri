'''numbs = [1,5,8,9,15,44]
rs = [i for i in numbs if i%2==0]
print(rs)'''
prıce = [1000,2000,3000,4000,9000,700,500,200]
vergı = []
'''for i in prıce:
    if (i>=1000):
        vergı.append(i*2.27)
    else:
        vergı.append(i*1.18)
print(vergı)'''
# yukarıda tanımladığımız şeyi aynı şekilde aşağıdaki gibide yapabiliriz
'''rs = [i*2.27 for i in prıce if(i>=1000) ]
print(rs)'''