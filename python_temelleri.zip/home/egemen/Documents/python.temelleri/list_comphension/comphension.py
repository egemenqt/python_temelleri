# expression (i*i for i in  range gibi komutla işlem yapılabilir) aşağıdaki gibi kullanılır
'''numbs = []
for i in range(10):
    numbs.append(i)
numbs=[i*i for i in numbs]
print(numbs)'''
#------------------------------------------------------------
'''names = ["ali","osman","ayşe","fatmA"]
rs = [i.capitalize() for i in names]
print(rs)'''
# numbs=[1,12,254,65,78]
rs =[i%12==0 for i in range(1,100)]
print(rs)