'''rs = [i for i in range(101) if (i%12==0)]
print(rs)'''
#-----------------------------------------------
'''names = ["ahmet","ali","çınar","deniz"]
rs = [i.capitalize()[::-1] for i in names]
print(rs)'''
#-----------------------------------------------
'''string = "hello 12345 world"
rs = [i  for i in string if (i.isdigit())]
print(rs)'''
#-----------------------------------------------
'''years = [1983,1999,2008,1956,1986]
import datetime
now = datetime.datetime.now().year
rs =[(now - i)  for i in years]
print(rs)'''
#-----------------------------------------------
dereceler = [20,5,15,-2,0,-6]
rs = [i if (i>=0) else   "buzlanma tehlikesi" for i in dereceler]
print(rs)

