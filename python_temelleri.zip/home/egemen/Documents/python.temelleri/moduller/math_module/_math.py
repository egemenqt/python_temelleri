#YÖNTEM 1
# import math         #math modülünü ettik
# '''value = dir(math)   #import edilen modül dir komutu ile içinde nelerin olduğunu gördük
# rs = help(math)'''     #help komutu ile math modülünün içinde ne işe yarar öğrenelim
# rs=help(math.factorial)#burada help math. dediğimiz zaman modülde kullanacağımız işlemler çıkar
#----------------------------------------------------------------
'''rs1 = math.sqrt(81)      #soldaki kullanım () içindeki sayının karekökünü alır
rs2 = math.floor(5.6)    #soldaki işlem () içindeki sayıyı tam sayının aşağısına yuvarlar
rs3 = math.ceil(5.6)     #soldaki işlem yukarı yuvarlama yapar    
rs4=math.factorial(4)    #soldaki kullanım () içindeki faktöryelini alır
print(rs1)
print(rs2)
print(rs3)
print(rs4)'''
#------------------------------------
#modüllere isim konulabilir
'''import math as islem
rs = islem.tan(90)
print(rs)'''
#YÖNTEM 2
from math import *
#burada math. deneme gerek yok
value = factorial(0)
value1 = sqrt(1080)
print(value)
print(value1)
