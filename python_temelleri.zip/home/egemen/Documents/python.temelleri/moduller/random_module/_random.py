import random
'''rs=random.randint(1,100)#    randint(a,b) a ve b arasında rastgele sayı üretir'''
'''rs=random.random()   #burada 0-1 arasında sayı üretir'''
# rs=random.uniform()           #burada uniform(a,b) a-b arasında ondalıklı sayı üretir
names=["ali","deniz","yağmur","nesli","ege"]
# rs =names[random.randint(0,len(names)-1)] #solda names listenin random modülü kullanarak rastgele isim getiririz
# print(rs)                                 #len(names)-1 çıkarmamızın sebebi outofrange
'''rs =random.choice(names)     #burada choice daha kolay olarak names listesinden rastgele değer getirir
print(rs)'''
'''numbs=list(range(10))
random.shuffle(numbs)           #shuffle komutu liste içindeki karakterlerin sıralarını rastgele değiştirir
print(numbs)'''
liste=list(range(100))
rs=random.sample(liste,3)  #burada liste içerisinden rastgele 3 farklı getirir
print(rs)