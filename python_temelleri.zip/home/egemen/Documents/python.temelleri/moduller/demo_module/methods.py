from db import *
def urunekle(ad,fiyat):
    products.append({"ürün ad":ad,"ürün id":len(products) + 1,"ürün fiyat":fiyat})
def urunguncelle(id,ad,fiyat):
    for urun in products:
        if(urun["ürün id"]==id):
            urun["ürün ad"]=ad
            urun["ürün fiyat"]=fiyat
            break
def urunlerigetir():
    return products