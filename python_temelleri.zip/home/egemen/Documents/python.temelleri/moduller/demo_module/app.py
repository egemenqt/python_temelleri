from methods import *
urunekle("iphone 11 pro",14000)
urunguncelle(2,"iphone 12 pro",16000)
print(urunlerigetir())