products=[{
"ürün ad":"iphone 8",
"ürün id":1,
"ürün fiyat":8000
},
{
"ürün ad":"iphone x",
"ürün id":2,
"ürün fiyat":9000
},
{
"ad":"iphone 12 pro",
"id":3,
"fiyat":12000
}]