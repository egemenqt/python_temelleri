import re
#re module
str='hello biatch sıska pete baby | ım sıska pete baby sıska pete'

# result1 = re.findall("baby",str) #findall komutu bize istediğimiz kelimeden kaç tane olduğunu listeler
# result = len(result1)


result=re.split(" ",str)        #split burada soldaki gibi kullanılıp tırnak içindeki karakterden böler
print(result)

result = re.sub(" ","-",str)    #burada sub metodu karakter değişikliği yapar
print(result)

result1 = re.search("pete",str)#search metodu ilk bulduğunu karakter arasını yazar
result2 = result1.span()         #span ilk karakterin  ile kaçıncı konumda olduğunu bulabilirsin
result3=result1.end()
result4=result1.group()
print(result3)



#regular expression
