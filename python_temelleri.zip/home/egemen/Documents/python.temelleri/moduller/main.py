'''import modül    #burada modül.py adlı projeyi buraya uyarlamış olduk böylelikle modül.py'da 
                #yaptığımız işlemleri main.py a import ederek burada yapabiliriz
rs=modül.sayi
rs1=modül.sayilar
rs2=modül._dict
print(rs)
print(rs1)
print(rs2)'''

#import edeceğin projeye isim verebilirsin
'''import modül as m
rs=m.sayi
rs2=m.sayilar
rs3=m._dict
print(rs)
print(rs2)
print(rs3)'''
#import edeceğin projeden istediğin işlemi çekebilirsin from komutu aşağıdaki gibi kullanılır
'''from modül import sayi,sayilar,_dict
print(sayilar)
print(sayi)
print(_dict)'''
#bütün hepsini import etmek için (from proje ismi import *)
'''from modül import *
print(sayi)
print(sayilar)
print(userinfo)'''