from datetime import *
simdi = datetime.now()
rs=simdi.date()
rs=datetime.ctime(simdi)       #ctime bize tarih konusunda daha açıklayıcı bilgi verir
rs1=datetime.timestamp(simdi)   # timestamp bize tarihi saniyeye çevirir 
rs2 = datetime.fromtimestamp(rs1)#fromtimestamp ise saniyeyi tarihe dönüştürür
rs2 = datetime.fromtimestamp(0)
rs = simdi - timedelta(10)      #timedelta komutu ile belirtilen tarih ve işaret timedelta 
rs = simdi + timedelta(10)      #içinde yazan sayı  kadar çıkarır
print(rs)                      
t='15 april 2019 hour 10:12:30'
result = datetime.strptime(t,'%d %B %Y hour %H:%M:%S') #burada bilgisayar string ifadeyi tarihe çevirdi
rs1 = simdi - result     #bundan sonra result için istediiğimiz işlemi yapabiliriz
print(result)              #!!!!!!!!!!!!!!!!!!!!!!!!
