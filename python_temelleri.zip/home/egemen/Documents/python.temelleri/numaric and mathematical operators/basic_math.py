#+ toplama
#- çıkarma
#* çarpma
#/ bölme
#** üs alma
#% mod alma (sayının bölümünden kalanı verir)
#// tam bölme (tam bölünmese bile tam kısmı bize verir) 
#bölme herzaman floattır
"""selamlar
"""
print("2+2")
print(type(8/2))