print('2+2')
#type verilerin sınıfına bakar örneğin type(selam) class string ifadesini verir
