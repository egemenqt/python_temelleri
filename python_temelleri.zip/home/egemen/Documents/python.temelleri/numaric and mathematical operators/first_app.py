print("helllo world")
#pythondan çalıstırmak için klasör oluşturulup içine
#çalıştıracağımız dosyanın sonuna .py olarak tanımlamamız gerekir
#terminal bize bilgisayarın okuduğu görüntüyü verir