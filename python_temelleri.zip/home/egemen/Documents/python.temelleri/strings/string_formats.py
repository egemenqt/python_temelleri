nm='sıska pete'
srnm='heyyoo'
age='23'
print("benim adım  {} soyadım  {}   ve yaşım {}".format(nm,srnm,age))  #süslü parantezlerden sonra .format yazarak hangi karakter nereye geldiğini isteyerek yapabilirsin

print("benim adım  {1} soyadım  {0}   ve yaşım {2}".format(nm,srnm,age))  #numara vererek yerlerini değiştireblirsin

print("benim adım {n}    ve yaşım  {m}".format(n=nm,m=age))

