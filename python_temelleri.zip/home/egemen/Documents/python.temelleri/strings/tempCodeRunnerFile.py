print(msg.index("kurs"))#index istediğiniz karakterin kaçtan itibaren başladığını gösterir
# print(msg.startswith("p"))#hangi harf ile başladığına bakabilirsin
# print(msg.endswith("z"))# aynı şekilde
