msg="python kursumuza hoşgeldiniz"
# print(msg.upper())#tüm karakterleri büyük harf yapar
# print(msg.lower())#tüm karakterleri küçük harf yapar
# print(msg.capitalize())#ilk harfi büyük yapar
# print(msg.title())#boşluktan sonraki harfleri büyük yapar
# print(msg.islower())# tüm harfler küçükmü diye sorar upper içinde geçerli
print(str(msg).split())#liste şeklinde tanımlar yanında kare parantez istediğin listedeki karakteri alır
# print(msg.index("kurs"))#index istediğiniz karakterin kaçtan itibaren başladığını gösterir
# print(msg.startswith("p"))#hangi harf ile başladığına bakabilirsin
# print(msg.endswith("z"))# aynı şekilde
# print(msg.replace("hoşgeldiniz","gardas"))#repalace yeniden koyma işlemidir
# print(msg.lower.replace(" ","/").replace("s","ş"))
