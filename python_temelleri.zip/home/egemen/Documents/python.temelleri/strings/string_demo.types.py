print(" hello world ".strip())#baş ve sondaki boşluk karakterlerini siler
print("www.sıskapete.com".replace("www."," ").replace(".com"," ").strip())
print("Websİtea baby".count("a"))#count karakteri kelimede kaç tane harf olduğunu bulur
print("website".startswith("www")) ,print("website".endswith(".com"))
print("kursadi".isalpha())# isalpha komutu harfler alfabetikmi diye sorar
print("Contents".center(50,"*"))#center ifadesi ortalanmıi dize dönüştürür
print("Contents".ljust(20,"*"))#sola alır kelimeyi ve sağa yıldız yapar
print("Contents".rjust(20,"*"))
print("helloworld".split())