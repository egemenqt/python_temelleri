from unittest import result


name='egemen'
surnm='yiğit'

print(name[1])# burda köşeli parantez hangi karakterin yazacağını ortaya çıkarır örneğin sıfırda e yazar
print(name[-1])#- ile yazarsak tersten başlar

result="adım:  "+name+"  soyadım:  "+surnm

print(len(result))  #lenght komutu karakterin uzunluğunu bize verir
print(result[:10])#başlangıçtan itibaren ilk 10 karakteri ekrana yazdırır tersi ise sondan
print(result[::1])# bu komut sağdan sola ekrana verir
print(result[::-1])#bu komut ekrana soldan sağa yazdırır
