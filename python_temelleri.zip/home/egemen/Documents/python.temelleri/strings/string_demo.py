#kursadında kaç karakter var
krn="helllooo whattupp biaaatcch sıska pete baby "
print(len(krn))

sıt="www.SıskaPeTe.COM"
#website içinden www karakterlerini alın
print(sıt[:3])

#wb com karakterlerini al
print(sıt[-3:])

#kursadı ilk ve son 5 karakteri al

# print(krn[::])

#kursadını tersten çevir

print(sıt[::-1])

#hello world ifadesindeki w harfini değiştirin değiştirme işlemi önemli


ır="hello world"

ch=ır[:6] + "b" + ır[-4:]

print(ch)

#abc yanyana üç defa yazdır  * komutu ile yapabilirsin

print("abc"*3)
#string methogs!!!!!
