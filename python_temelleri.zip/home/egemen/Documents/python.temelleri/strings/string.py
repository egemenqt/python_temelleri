name='egemen'# str tipidir + ile değişkenler yazılabilir
surnm='yiğit'
age='19 '
result="benim adım: "+name+ " "+ "soyadım:  "+surnm+"  "+"yaşım:   "+age
print(result)