numbs=[1,2,3,4,5]
iterator = iter(numbs)      #next metodu liste elemanlarını tek tek dolaşır
# print(next(iterator))       #iter etmeden next çalıştırılamaz
while True:
    try:
        print(next(iterator))
    except StopIteration:
        print("son!")
        break
