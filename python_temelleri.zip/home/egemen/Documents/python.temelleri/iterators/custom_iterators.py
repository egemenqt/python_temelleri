numbs=[1,2,3,4,5]
def std(iterable,func): 
    iterator = iter(iterable)
    while True:
        try:
            rs=next(iterator)
            func(rs)
        except StopIteration:
            print("son!")
            break
# std(numbs,print)
def lks(x):
    print((x*x))
std(numbs,lks)