#dosya kopyalama

def dosya_kopyalama(old_file, new_file):
    with open("dosya1.txt","r+",encoding="UTF-8") as dosya1:
        with open("markalar.txt","r+",encoding="UTF-8") as dosya2:
            old_file = dosya1
            new_file = dosya2
            old_file.seek(0)
            new_file.write(old_file.read())
            new_file.seek(0)
            print(new_file.read())
            

# dosya_kopyalama("eski","yeni")
    
#-----------------------------------------------------------------------------------------

#tersten yazdırma işlemi
def ters_cevir(old_file, new_file):
    with open("dosya1.txt","r+",encoding="UTF-8") as dosya1:
        with open("markalar.txt","r+",encoding="UTF-8") as dosya2:
                old_file = dosya1.read()
                new_file = dosya2
                new_file.write(old_file[::-1])
                new_file.seek(0)
                print(new_file.read())

# ters_cevir("eski","yeni")



#---------------------------------------------------------------------------------------------------------
#dosya hakkında bilgilendirme



def bilgilendirme(fn):
    def inner_(*args, **kwargs):
        return fn(*args, **kwargs)
    return inner_

@bilgilendirme
def satir_sayisi(file_name):
    with open(file_name,"r+",encoding="UTF-8") as dosya1:
        new_file = dosya1.readlines()
        print(f"açık satır sayısı:{len(new_file)}")
        
@bilgilendirme
def kelime_sayisi(file_name):
    with open(file_name,"r+",encoding="UTF-8") as dosya1:
        new_file = dosya1.read()
        result = str(new_file).split()
        print(f"kelime sayısı:{len(result)}")



def karakter_sayisi(file_name):
    with open(file_name, 'r+',encoding="UTF-8") as dosya1:
        new_file = dosya1.read()
        result = new_file.strip()
        print(f"karakter sayısı:{len(result)}")



# satir_sayisi("dosya1.txt")
kelime_sayisi("dosya1.txt")
# karakter_sayisi("dosya1.txt")