# "w" :yazma modu
# ** dosyayı konumda oluşturur
# ** eğer aynı dosya varsa siler ve yenisini oluşturur
with open("dosya1.txt","w",encoding="UTF-8") as file:
    file.write("selam\n")
    file.write("beni bulamazsınız\n")
    print(file)

with open("dosya1.txt") as file:
    print(file.read())