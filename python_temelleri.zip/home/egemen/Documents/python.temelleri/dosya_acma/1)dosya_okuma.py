#dosya açmak ve oluşturmak için open() fonksiyonu kullanılır
#KULANIMI: open(dosya_adı,dosya_modu)
#dosya_erişme_modu => dosyayı hangi amaçla açtığımızı belirtir
#"r":okuma modu => belirtilen konumda dosya olmalıdır

reading=open("dosya2.txt")
print(reading.read())


