with open("markalar.txt","r+",encoding="UTF-8") as file:
    file.write("1-ford\n")
    file.write("2-bmw\n")
    file.write("4-mercedes\n")

with open("markalar.txt","r+",encoding="UTF-8")as file:
    pass
with open("markalar.txt","r+",encoding="UTF-8") as file:
    print(file.read())


#file.truncate() bu metod cursorun son geldiği noktadan sona kadar silmesini sağlar 
#içine sayi parametre atarsan atadığın sayı kadar sona kadar cursor siler