#reading.seek(0) //burada atadığın open("dosya1.txt") ile cursoru en başa alırsınız
#seek(sayi) //içine yazılan sayı kadar karakter gider cursor
#reading.readline() // en baştan başlar satır sonuna kadar okur
#reading.readlines() // bütün satırları liste şeklinde okur
reading=open("dosya1.txt")
# print(reading.read())
# reading.seek(5)
# print(reading.readline())
# satir=reading.readlines()[2]#burada readlines liste olduğu için satırı yazarak gidebilirsin
#n-1 şeklinde gider
# reading.close()#dosyayı kapatır 

