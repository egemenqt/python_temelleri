
 #endconding="utf-8" türkçe karakterleti okur
with open("dosya1.txt","r",encoding="UTF-8") as file:
    print(file.read())
    print(file.tell()) #cursorun bize nere olduğunu söyler
    
    #with kapsamına çıktığında oluşturulan file biticek yani close demene gerek yok with içinde iken




