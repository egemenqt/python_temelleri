#kullanıcıdan alınan ürün bilgisi (ad,fiyat) urunler.txt kaydet
def kayit_islemi():
    with open("urunler.txt","r+",encoding="UTF-8") as dosya1:
        kac_urun = int(input("kaç ürün eklemek istiyorsunuz:"))
        for i in range(0, kac_urun):
            name = input("ürün adını giriniz:")
            price = int(input("ürün fiyatını giriniz:"))
            new_file = dosya1.write("eklenen ürün adı:{}     eklenen ürün fiyatı:{}\n".format(name,price))
        dosya1.seek(0)
        print(dosya1.read())

# kayit_islemi()

#----------------------------------------------------------------
#dosya ismi,eski kelime ve yeni kelime parametreleri alarak güncelleme yapan

def info_(fn):
    def inner(*args, **kwargs):
        if FileNotFoundError(fn):
            print(f"{fn} dosyası bulunamadı farklı klasörde olabilir!")
        else:
            with open(fn,"r+",encoding="UTF-8") as dosya1:
                user_choose = int(input("dosya yazma 1)\ndosya okuma 2)\nseçiminiz:"))
                if user_choose==1:
                    inner_choose = int(input("dosyanın üstüne yazmak için 1)\ndosyanın içeriğini silip baştan yazmak için 2)\nseçiminiz:"))
                    if inner_choose==1:
                        user_text = input(":")
                        dosya1.write(user_text)
                        dosya1.seek(0)
                        print(dosya1.read())
        return fn(*args, **kwargs)
    return inner


@info_
def name_alma_(file):
    file = input("değişiklik yapmak istediğiniz dosya ismi nedir?\n:")
name_alma_("sa")


