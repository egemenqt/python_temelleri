with open("dosya1.txt","a") as file: #"a" ekleme modudur burada dosyaya silmeden ekleme yapılır
    file.write("kimse bulamaz\n")   #cursorun konumunu değiştirmek append metodunun ekleme yerini değiştirmez
                                    #"r+" modu ile en başa ekleyebilirsin

with open("dosya1.txt","r+") as file:#"r+" modu ile cursoru hareket ettirebilirsin
    file.read()
    file.write("bana bulasma")