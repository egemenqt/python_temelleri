#key - value  içindeki bilgiler değiştirilebilir ancak sıralanamaz

plaka = {"istanbul" : 34 , "izmir ": 35, } 
# print(type(plaka))
# print(plaka["istanbul"],plaka["izmir "])    değerini key ile bulabilirsin value değeri ile bulamazsın
sti=  { 1: {
    "name" : "Pete",
    "surname" : "parker",
    "age"   :   19 ,    },
    2 : {
        "name" : "Egemen",
        "surname": " yiğit",
        "age" : 19
    }
}
print(sti[2]["age"])
