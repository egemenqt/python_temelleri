#1-3 ürün bilgisii kullanıcıdan(id,ad,fiyat) şeklinde dictionary içinde saklayınız
#2- ürünün id bilgisini alıp ilgili ürünü kullanıcı bulsub
uruni = int(input("ürün id giriniz:  "))
uruna = input("ürün ad giriniz:  ")
urunf = int(input("ürün fiyat giriniz:  "))
uruni2 = int(input("2.ürün id giriniz:  "))
uruna2 = input("2.ürün ad giriniz:  ")
urunf2 = int(input("2.ürün fiyat giriniz:  "))
uruni3 = int(input("3.ürün id giriniz:  "))
uruna3 = input("3.ürün ad giriniz:  ")
urunf3 = int(input("3.ürün fiyat giriniz:  "))
inf1={
    "ürünün id: ": uruni,
    "ürünün  adı: ": uruna,
    "ürünün fiyatı:  ": urunf
}
inf1={
    "ürünün id: ": uruni2,
    "ürünün  adı: ": uruna2,
    "ürünün fiyatı:  ": urunf2
}
inf1={
    "ürünün id: ": uruni3,
    "ürünün  adı: ": uruna3,
    "ürünün fiyatı:  ": urunf3
}
print(inf1)


