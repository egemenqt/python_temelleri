# msg='hello world ım sıska pete whatt up biattchh'
# numbers=[1,2,3,4,5,6,9]
# print(numbers)
perinf=[["ali",15],["ahmet",22]]
print(perinf[0],perinf[1])

