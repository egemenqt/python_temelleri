x=5         #sayılarda yapılan değişiklik referansı aynı yere götürmez 
y=25
x=y
y=10
print(x,y)
# ///////////////////////////////////////////
cars=["ford","mercedes","audi","maseratı"]    # liste tipi için .copy ifadesini kullanırsan farklı referans olur
cars2=["bmw","aston martin","bugattı"]
cars.copy()
cars[0]="mazda"
print(cars)
print(cars2)