import re


phone=['samsung s5','samsung s6','samsung s7','samsung s8']
# print(len(phone))#len listede kaç eleman olduğuna bakar
# print(phone[0],phone.pop())  pop komutu listedeki son karakteri ekrana yazdırır
# phone[0] = "samsung s9"
# print(phone)
# print(phone.index("samsung s7")) # index listede belirtilen elemanı bulur 
# print(phone[0:2])
# result = phone[:2] + ['samsung s9']+['samsung s10']
# print(result)
# del phone[-1]
# print(phone)
# print(phone[::-1])
usera= ["Yiğit","Bilgi",2010,[70,60,70]]
userb= ["Sena","Turan",1999,[80,70,80]]
userc= ["Ahmet","Turan",1998,[80,70,90]]
# result= "öğrenci ismi : {}  soyismi:  {}     doğum yılı:  {}   aldığı notlar:  {}, {}, {}".format()
# print(result)
print("öğrenci bilgileri: ",[usera])
print("öğrenci bilgileri: ",[userb])
print("öğrenci bilgileri: ",[userc])
avarage1=(usera[3][0]+usera[3][1]+usera[3][2])/3
avarage2=(userb[3][0]+userb[3][1]+userb[3][2])/3
avarage3=(userc[3][0]+userc[3][1]+userc[3][2])/3
print("öğrenci ortalamaları=  / Yiğit: {}  / sena:  {}/  Ahmet:  {} ".format(avarage1,avarage2,avarage3))