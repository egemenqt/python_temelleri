
lang = ['HTML','JAVA','C#','PYTHON']
# print(lang[2])#köşeli parantez listede istenilen karakter ifadeyi verir
res=lang+['C++','TOR BROWSER']# listeye ekleme yapılabilir
# x=input("bir dil değeri giriniz")
# if x in lang:
#     print("değer listenin bir elemanıdır")
# else:
#     print("listenin elemanı değildir")
# print(x)
del res[0]
print(res)
