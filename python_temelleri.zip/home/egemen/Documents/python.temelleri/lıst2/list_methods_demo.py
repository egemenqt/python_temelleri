names = ["Ada","Yiğit","Hasan","Beril"]
dogyıl = [1998,2000,1998,1987]
# names.append("Cenk")
# print(names)
# names.insert(0,"Sena")
# print(names)
# names.remove("Yiğit")
# print(names)
# print(names.count("Yiğit"))
# names.reverse()
# print(names)
# names.sort()
# print(names)
#ogyıl.sort()
# print(dogyıl)
ph = "iphone x,iphone xr"
phl = ph.split(",")    #split ifadesi string ifadeyi listeye çevirir soldaki gibi kullanılır
#print(dogyıl)
# dogyıl.clear()
# print(dogyıl)
print(phl)