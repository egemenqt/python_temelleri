mark= {
    "model: ": "corsa",
    "yıl" : "2020",
    "marka ": "opel"
}
# rs1=mark["marka "]
#value keye karşılık gelen bilgiyi verir
# rs1="marka" in mark in komutu değişkenin içinde olan keyi bulur
# rs1=len(mark) len komutu key valueden kaç tane olduğunu bulur
# mark["renk"] = "kırmızı" # ekleme metodu soldaki gibi yapılır
# mark.pop("yıl") pop dictionary içindeki atadığınız key-valueyi siler
# mark.popitem()  pop item sondaki key-valueyi siler
# del mark["model: "]  aynı şey del içinde geçerli
# obj = mark.copy() # .copy komutu bize farklı referans noktası verir kopyalar değiştirmek için birebirdir
# mark["marka "] = "mazda"
# mark["model: "]="rx7"
# print(obj)
'''mark.update({          #update komutu istediğini güncelleyebilir ekleme yapabilirsin
    "marka ": "Mustang",
    "renk ": "kırmızı"
})'''

# print(rs1)


