#tuple listeden farkı değiştirilemezdir daha az yer kaplar ve daha performanslıdır appden ve remove komutları kullanılmaz
#tuple listeden tek farkı değiştirilemez !!!!!

_tupl2 = (1,4,56,24)
_tupl3= (12,"ege",True)
_list2= [24,55,75]
print(_tupl3.index(True))
print(_tupl3.count("ege"))
print(_tupl2)
print(_list2)
#listeler tupleye çevrilebilir
lists2 = ["sıska pete",245,"BMW",900.000]
_tupl4 = tuple(lists2)
print(type(_tupl4))