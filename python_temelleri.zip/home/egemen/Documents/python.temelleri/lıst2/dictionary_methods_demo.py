id=input("oyuncu id giriniz: ")
name= input("oyuncunun adını giriniz: ")
age= input("oyuncunun yaşını giriniz: ")
ht= input("oyuncunun oynadığı takımları giriniz: ")
id2=input("oyuncu id giriniz: ")
name2 =input("oyuncunun adını giriniz: ")
age2= input("oyuncunun yaşını giriniz: ")
ht2= input("oyuncunun oynadığı takımları giriniz: ")
players={id:{1:{
    "oyuncunun id: " : id,
    "oyuncunun adı" : name,
    "oyuncunun yaşı ": age,
    "oyuncunun oynadığı takımlar: ":ht}},
    2:{
        "oyuncunun id: " : id2,
    "oyuncunun adı" : name2,
    "oyuncunun yaşı ": age2,
    "oyuncunun oynadığı takımlar: " : ht2
    }}

id = input("aramak istediğiniz id:")
players.get(id)
print(players)

