# 3 ürün dictionary saklanacak(id,ad,fiyat)     kullanıcıdan idi istenip bilgi verilecek
id=(int(input("ürünün id numarasını giriniz: ")))
ad= input("ürünün adını giriniz")
prıce=int(input("ürünün fiyatını giriniz: "))
id=(int(input("2.ürünün id numarasını giriniz: ")))
ad= input("2.ürünün adını giriniz")
prıce=int(input("2.ürünün fiyatını giriniz: "))
uruns={
    "ürünün adı": ad,
    "ürünün fiyatı":prıce
}
print(uruns)