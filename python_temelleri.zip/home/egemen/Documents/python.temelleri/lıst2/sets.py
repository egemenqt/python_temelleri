fruits = {"apple","banana","cherry"} # sets indexlenemez/sıralanamaz/ekleme yapılabilir/silme yapılabilir
fruits.update(["orange","carrot","apple"])   #update işlemi
fruits.add("melon")                  #add ekleme işlemi
fruits.remove("apple")               #silme işlemi
fruits.discard("melon") #silme işlemi
rs1=len(fruits)
print(rs1)
print(fruits)