numbs= [1,3,65,78,342,52,67,97,97,97]
letters=['a','b','k','asd','fras']
#listeye ekleme  listeye ekleme kısmında bir satırda yapılır ayrı !!!!!
'''numbs.append(10)
numbs.insert(2,25)
print(numbs)
'''
#listeden silme kısmı!!!
'''numbs.pop(3) / pop işlemi kaçıncı indexte silmek istersen onu siler
numbs.remove(78) / remove işlemi atadığın değeri siler
print(numbs)'''

#sıralama
# numbs.sort()# bu komut küçükten büyüğe sıralar /sort
# numbs.reverse()#bu komut büyükten küçüğe sıralar / reverse
# result = numbs.count(97)# count komutu listede o karakterden kaç tane olduğunu gösterir
# result = numbs.index(342) index kaçıncı yerde olduğunu bulur

