class Person:
    def __init__(self,name,age):
        self.name=name
        self.age=age

    def show_person(self):
        print(self.name,self.age)

class Student(Person):
    pass

class Teacher(Person):
    pass

student1=Student("ege",19)
student1.show_person()
teacher1=Teacher("nesli",20)
teacher1.show_person()
