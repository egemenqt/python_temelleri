class NewDict(dict):            #class için dictionary yapısı soldaki gibi tanımlanır
    def __repr__(self):
        print("repr çalışıyor")
        return super().__repr__()           #super() base classtan fonk çağırır

    def __missing__(self):          #missing metodu key yok ise çalışır
        print("olmayan key bilgisini çağırıyorsunuz!")
        
    def __getitem__(self,key):          #getitem metodu key bilgisini getirir
        print("key bilgisi çağırıyorsunuz!")
        return super().__getitem__(key)

    def __setitem__(self,key,value):    #setitem metodu key ekleme ve düzenleme yapar
        print("key bilgisi ekliyor veya düzenliyorsunuz!")
        return super().__setitem__(key, value)

    def __contains__(self,key):
        return super().__contains__(key)
        print(False)
data = NewDict({"key1":"value1","key2":"value2"}) 

# print(data)
# data["ege"]
# print(data["key1"])

# data["key2"]="wtf"
# data["key3"]="value3"

# print(data)

print("" in data)