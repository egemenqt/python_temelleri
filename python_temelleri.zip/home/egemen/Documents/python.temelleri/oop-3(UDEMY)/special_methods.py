class Film:
    def __init__(self,filmbaslik,filmsure):
        self.filmbaslik=filmbaslik
        self.filmsure=filmsure
    def __str__(self):
        return f"{self.filmbaslik} isimli film süresi :{self.filmsure} "

    def __repr__(self):
        return "repr çalışıyor"        

    def __del__(self):
        print("film objesi silindi")

film1=Film("std",755)
print(str(film1))
print(repr(film1))  #information project for developer
del film1


