class Product:
    def __init__(self,name,price):
        self.name=name
        if price>=0:
            self._price=price
        else:
            raise ValueError("lütfen negatif değer girmeyiniz")
    # def set_price(self,value):
    #     if value>=0:
    #         self._price=value
    #     else:
    #         raise ValueError("lütfen negatif değer girmeyiniz")

    # def get_price(self):
    #     return  self._price
    @property
    def price(self):
        return self._price

    @price.setter
    def price(self,value):

        if value>=0:
            self._price=value
        else:
            raise ValueError("lütfen negatif değer girmeyiniz")


p1=Product("süt",800)
# p1.price=-800           #eğer burada -800 yaparsan raise dönmez ve -800 yazar 
print(p1.name,p1.price)     #bu yüzden _price ile set edicez

# p1.set_price(800)
# print(p1.get_price())

p1.price=700
print(p1.price)