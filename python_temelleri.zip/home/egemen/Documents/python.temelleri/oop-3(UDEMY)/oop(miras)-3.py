class Person:           #base class 
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def show_person(self):
        print(self.name,self.age)
        

class Student(Person):
    def __init__(self, name, age,number):
        super().__init__(name,age)
        self.number = number
    
    def study_working(self):
        return f"{self.number} numaralı öğrenci ders çalışıyor"

class Teacher(Person):
    def __init__(self, name, age,branch):
        super().__init__(name,age)
        self.branch = branch

    def teacher_working(self):
        return f"{self.branch} branşlı öğretmen  ders anlatıyor"

student1=Student("ege",19,500)
print(student1.study_working())
student1.show_person()
teacher1=Teacher("nesli",20,"endstüri")
print(teacher1.teacher_working())
teacher1.show_person()
