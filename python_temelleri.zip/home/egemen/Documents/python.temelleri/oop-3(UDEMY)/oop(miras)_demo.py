#user
#moderator
class User:
    active_user=0
    def __init__(self,username,age):
        self.username = username
        self.age = age

    def log_in(self):
        User.active_user+=1
        return f"{self.username} giriş yaptı"

    def log_out(self):
        User.active_user-=1
        return f"{self.username} çıkış yaptı"

    def show_user(self):
        return f"kullanıcı adı:{self.username}   yaş:{self.age}"    

    @classmethod                #classmethod senden parametre istemez User.active_userfonx() çağıurarak çalıştırabilirsin
    def active_userfonx(cls):
        return  f"{cls.active_user} anlık aktif kullanıcı "


class Moderator(User):

    active_moderator=0

    def __init__(self, username, age):
        super().__init__(username, age)
        Moderator.active_moderator+=1
    @classmethod
    def active_moderatorfonx(cls):
        return  f"{cls.active_moderator} aktif moderatör var"


User.active_userfonx()

user1=User("xkraltr",19)
print(user1.log_in())

print(User.active_userfonx())

user2=User("std",19)
print(user2.log_in())

print(User.active_userfonx())


mod1=User("bckstadit",19)
print(mod1.log_in())
mod1.active_userfonx()
print(Moderator.active_moderatorfonx())
print(User.active_userfonx())

