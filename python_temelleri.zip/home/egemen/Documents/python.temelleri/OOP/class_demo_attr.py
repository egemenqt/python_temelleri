class Pet:
    cinsler=["kedi","köpek","balık"]
    def __init__(self,name,tur):
        if tur not in Pet.cinsler:
            raise ValueError(f"{tur} bir  evcil hayvan değil!")       
        self.name=name
        self.tur=tur
    def set__init__(self,tur):
        if tur not in Pet.cinsler:
            raise ValueError(f"{tur} bir evcil haycan değildir!")
        self.tur=tur
boncuk=Pet("boncuk","kedi")        
alfred=Pet("alfred","köpek")        
# alex=Pet("alex","aslan")
stz=Pet("stz","köpek")
stz.set__init__("balık")
print(boncuk.name,boncuk.tur)
print(alfred.name,alfred.tur)
print(stz.name,stz.tur)
