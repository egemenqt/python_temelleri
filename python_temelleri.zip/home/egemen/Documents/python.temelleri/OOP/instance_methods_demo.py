class  BankAccount:
    def __init__(self,name):
        self.owner=name
        self.balance=0.0
    def getbalance(self):
        return self.balance
    def deposit(self,ytmiktar):
        self.balance+=ytmiktar
    def withdraw(self,çkmiktar):
        self.balance-=çkmiktar
hesap = BankAccount("egemen yiğit")
print(hesap.owner)
print(hesap.getbalance())
hesap.deposit(1000)
print(hesap.getbalance())
hesap.withdraw(500)
print(hesap.getbalance())