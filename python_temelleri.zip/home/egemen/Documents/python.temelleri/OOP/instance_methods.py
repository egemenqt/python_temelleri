class Person:
    #yapıcı metodlar
    def __init__(self, name,surname,birthofyear):
        #object attributes
        self.name = name
        self.surname = surname
        self.birthofyear = birthofyear
    #instance methods
    def intro(self):
        import datetime
        now=datetime.datetime.now().year
        return  f"my name is {p1.name}  {p1.surname}   my birthdayyear:{p1.birthofyear} my age:{now - self.birthofyear}"
p1=Person("egemen","yiğit",1967)
print(p1.intro())