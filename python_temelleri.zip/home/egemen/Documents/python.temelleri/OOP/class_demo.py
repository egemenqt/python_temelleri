import termcolor
class   Comment:
    def __init__(self,username,text,likes,dislikes):
        self.username = username
        self.text = text
        self.likes = likes
        self.dislikes = dislikes
p1=Comment("ege","çirkin",100,20)
p2=Comment("sena","güzel",800,120)
p3=Comment("gökselin","hasta",500,220)
p4=Comment("ali","iyi",1100,520)
p5=Comment("neslin","kötü",5100,620)
p=[p1,p2,p3,p4,p5]
for i in p:
    print(f"------------------------------------------\n{i.username}\n          yorum:{i.text}\nlikes:{i.likes}             dislikes:{i.dislikes}")