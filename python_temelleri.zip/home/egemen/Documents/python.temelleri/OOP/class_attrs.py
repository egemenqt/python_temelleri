class User:
    active_user=0
    def __init__(self,name,surname,age):
        User.active_user+=1
        self.name=name
        self.surname=surname
        self.age=age
    def intro(self):
        return f"name is {self.name} {self.surname} ı'm {self.age} years old"
    def logout(self):
        User.active_user-=1
        return f"{self.name} {self.surname} çıkış yaptı."
    def login(self):
        User.active_user+=1
        return f"{self.name} {self.surname} giriş yaptı."
hesap_userA=User("egemen","yiğit",19)
hesap_userB=User("ali","demir",19)
hesap_userC=User("enver","kıyak",19)
hesap_userD=User("samet","ayaz",19)
print(hesap_userA.active_user)
print(hesap_userA.intro())
print(hesap_userA.active_user)
print(hesap_userB.login())
print(hesap_userB.active_user)
print(hesap_userD.logout())
print(hesap_userD.active_user)