#class  değişken oluştururken küçük harf class oluştururken büük harf lkullan
#sınıf tanımlama
#amaç istediğimiz bilgilerin her birini düzene istediğiiz şekilde sokmak
#class
class Ogrenci:
    pass
#object,Instance    nesnelerin herbiri bellekte ayrı yer kaplar 
ogrenci=Ogrenci()
print(type(ogrenci))
