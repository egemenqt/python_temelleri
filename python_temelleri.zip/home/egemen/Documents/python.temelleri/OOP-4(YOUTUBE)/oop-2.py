class Calisan():
    zam_ori=1.05
    def __init__(self,name,maas): #__init__ fonksiyonu class'ta çalışan ilk fonksiyondur
        self.personalname = name
        self.personalmaas = maas

    def _fullname(self):
        return "ad:{}\nmaaş:{}".format(self.personalname,Calisan._maasart(self))
    
    def _maasart(self):
        self.personalmaas= self.personalmaas*Calisan.zam_ori
        return self.personalmaas


personal1=Calisan("egemen",50)
personal1.zam_ori=1.2
personal1._maasart()
print(personal1._fullname())




