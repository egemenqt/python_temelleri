class Calisan():
    def __init__(self,name,maas): #__init__ fonksiyonu class'ta çalışan ilk fonksiyondur
        self.personalname = name
        self.personalmaas = maas
    def _fullname(self):
        return "ad:{}\nmaaş:{}".format(self.personalname,self.personalmaas)


personal1=Calisan("egemen",50)

print(personal1._fullname())
