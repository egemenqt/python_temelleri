class Calisan():
    zam_ori=1.05
    def __init__(self,name,maas): #__init__ fonksiyonu class'ta çalışan ilk fonksiyondur
        self.personalname = name
        self.personalmaas = maas
        
    def _maasart(self):
        self.personalmaas= self.personalmaas*self.zam_ori
        return self.personalmaas


    def _fullname(self):
        return "ad:{}\nmaaş:{}".format(self.personalname,self.personalmaas)


    @classmethod        #classmethod sınıfın tümünü kapsayan fonksiyondur
    def _yeni_ogran(cls):
        cls.yeni_ogran=float(input("yeni oranı giriniz:"))
        Calisan.zam_ori=cls.yeni_ogran


    # @classmethod
    # def _yeni_personal(cls):
    #     ad,maas=mpersonal.split("-")
    #     return cls(ad,int(maas))

class Gelistirici(Calisan):
    def __init__(self,name,maas):
        super().__init__(name,maas)



g1=Gelistirici("egemen",500)
g1._yeni_ogran()
g1._maasart()
print(g1._fullname())





# mpersonal="ege-90"
# mpersonal=Calisan._yeni_personal()
# mpersonal._yeni_ogran()
# mpersonal._maasart()
# print(mpersonal._fullname())



# personal1=Calisan("egemen",50)
# personal2=Calisan("samet",70)
# # personal1.zam_ori=1.5
# personal2._yeni_ogran()
# personal1._yeni_ogran()
# personal1._maasart()
# personal2._maasart()
# print(personal1._fullname())
# print(personal2._fullname())





