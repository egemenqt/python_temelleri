# numbs = [1,2,3,4,5]
# nam = "ali","elif","safinaz"
# _tuple = ("egemen"),("safinaz"),("cin ali")
'''_dictionary = {"salak":1,"mal":2,"aptal":3}
for i in _dictionary:
    print(i,_dictionary[i])
for x,y in _dictionary.items():
    print(x,y)''' 