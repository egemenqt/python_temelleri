numbs = [1,5,15,35,57,72]
'''for numb in numbs:
    print(numb)'''
#---------------------------------
'''for k5 in numbs:
    if(k5 % 5==0):
        print(k5)'''
#------------------------------------------------------
'''total=0
for numbt in numbs:
    total = total + numbt
print(total)'''
#-------------------------------------------
'''for cıftnumb in numbs:
    cıftnumb%2==0
print(cıftnumb**2)'''
#-----------------------------------
products = ["iphone 8","iphone x","iphone xr","samsung s10"]
'''for x in products:
    print(x[1])'''
#--------------------------------------------
for x in products:
    print(x.count("iphone"))