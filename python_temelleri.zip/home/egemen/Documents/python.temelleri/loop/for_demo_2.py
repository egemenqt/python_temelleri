products = [
    {"name":"iphone 8","price":4000},
    {"name":"iphone 8 plus","price":5000},
    {"name":"iphone X","price":6000},
    {"name":"iphone XR","price":7000},
    {"name":"iphone 11","price":8000},
]
for i in products:
    print(i)
#-----------------------------------
'''total = 0
for i in products:
    total+= i["price"]
print(f"ürün toplamı:  {total} TL")'''
#--------------------------------------------------
'''for urun in products:
    if (urun["price"]<=6000):
        print(f"ürünler: {urun['name']}")'''
#-----------------------------------------------------
'''foundproduct = input("aramak istediğiniz ürün:  ")
for i in products:
    if(foundproduct== i["name"]):
        print(f"ürün ismi: {i['name']}  /    ürün fiyatı: {i['price']}")'''
#////////////////////////////////////////////////////////////////////// 2.yol