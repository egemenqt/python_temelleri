import random
rastgelesayi = random.randint(0,100)
oyuncuhak = int(input("oyuncu hakkı giriniz:"))
'''print(rastgelesayi)'''
while(0<oyuncuhak):
    oyuncuhak-=1
    kalanhak = oyuncuhak
    biloyuncu = int(input("0-100 arasında sayı tahmin ediniz:"))
    if(biloyuncu==rastgelesayi):
        puan = (kalanhak +1)*20
        print("tebrikler doğru tahmin puanınız:{}".format(puan))
        break
    print("{} hakkınız var".format(oyuncuhak))
    if(biloyuncu<rastgelesayi):
        print("daha büyük sayı giriniz.")
    else:
        print("daha küçük sayı giriniz.")
    if(oyuncuhak==0):
        print(f"üzgünüz hakkınız doldu sayı {rastgelesayi} idi")
        print("puanınız 0")
