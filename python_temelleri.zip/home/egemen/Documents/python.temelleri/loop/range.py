'''#range metodu list olmasa bile list oluşturup aralık belirler
r = range(0,100)
for i in r:
    print(i)
for t in range(0,100,2): #range(a,b,c) 2.virgül aralığın kaçar kaçar gideceğini yazar
    print(t)'''
for i in range(10,0,-1):  # aynı şekilde terstende yazdırılabilir
    print(i)