
'''i = 0
while i<1000:
    i+=1
    print(i)'''
#While döngüsünün for döngüsünden farkı ise for döngüsünün kaç kez çalışacağı belli olan döngülerde,
# while döngüsünün ise kaç kez çalışacağı belli olmayan döngülerde kullanılmasıdır. 
# For döngüsünde yapılabilecek her işlem while döngüsünde de ek değişkenlerle sayesinde yapılmaktadır
usnm=""
while not  usnm:
    usnm = input("kullanıcı adınızı giriniz: ")
print("kullanıcı adınız: {}".format(usnm))
#while koşula  bağlıdır