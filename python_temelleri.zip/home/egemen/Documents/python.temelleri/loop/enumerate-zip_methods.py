# enumerate metodu numaralandırmak için kullanılır örneği aşşağıda
cars = ["opel","hyundai","nissan","toyota"]
rs = enumerate(cars)#           enumerate metodu liste karakterlerini numaralandırmak için birebirdir
print(list(rs)) #enumerate sonrasında list şeklinde tanımlamak önemlidir/
#------------------------------------------------------------------------------
#zip metodu birden fazla listeyi birbirine indexlemek için kullanılır aşşağıda görülşdüğü gibi
lıst1 = [1,2,3,4,5]
lıst2= ["bmw","mercedes","ferrari","aston martin","bentley"]
print(list(zip(lıst1,lıst2)))       #zip metodunda bir listeye fazladan index koyarsan outputa yazdırmaz!!
