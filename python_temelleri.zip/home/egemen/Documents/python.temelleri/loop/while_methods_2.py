userproductnmb = int(input("kaç ürün girmek istiyorsunuz: "))
i = 1
products = []
while (i<=userproductnmb):
    productname =input(f"{i}.  ürünün adını giriniz:")
    productprıce =input(f"{i}. ürünün fiyatı: ")
    products.append({
    f"{i}. ürünün adı:":productname,
    f"{i}. ürünün fiyatı:":productprıce
    })
    i+=1
print(products)
"""
for product in products:
    print(f"{i}.ürünün adı: {productname}\n{i}.ürünün fiyatı:{productprıce}")
"""