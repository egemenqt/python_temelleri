'''names = ["ali","osman","ayşe","ege","deniz"]
for name in names:
    if (name=="ege"):       #break komutu sadece looplarda kullanılır ve koşul ifadesi için kullanılır
        break               # örneğin name=="ege" break dendiği zaman egeden sonrasını outputa göstermez
    print(name) 
numbs = [32,87,45,19,785,64]
for numb in numbs:
    if(numb==numbs[4]):
        continue            #continue komutu solda görüldüğü gibi koşula bağlı sadece looplarda kullanılır
    print(numb)             #continue komutu eşitliktekinden sonrasını yazdırır ama eşit olanı yazdırmaz
''' 
i=0
total=0
while (i<100):
    i+=1
    if (i%2==1):
        continue
    total+=i
print(total)