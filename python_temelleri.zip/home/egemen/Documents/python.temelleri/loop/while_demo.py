# numbs = [4,6,9,10,35,57,89,125,244]
#----------------------------------------------------
'''while i<=10:
    i+=1
    print(numbs)'''
#---------------------------------------
'''i= 100
while 1<i<101:
    i-=1
    print(i)'''
#---------------------------------------
'''numbs=[]
i=0
while i<5:
    i+=1
    numb = int(input("sayı giriniz: "))
    numbs.append(numb)
numbs.sort()
print(numbs)'''