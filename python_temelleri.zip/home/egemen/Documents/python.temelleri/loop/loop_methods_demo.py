'''for i in range(1,11):
    print("---------")
    for k in range(1,11):
        print("{}x{}={}".format(i,k,i*k))'''
#-----------------------------------------------
'''asnumb = int(input("bir sayı giriniz: "))
if (asnumb%2==0):
    print("sayı asal değildir")
elif(asnumb%3==0):
    print("sayı asal değildir")
elif(asnumb%4==0):
    print("sayı asal değildir")
elif(asnumb%5==0):
    print("sayı asal değildir")
elif(asnumb%6==0):
    print("sayı asal değildir")
elif(asnumb%7==0):
    print("sayı asal değildir")
elif(asnumb%8==0):
    print("sayı asal değildir")
elif(asnumb%9==0):
    print("sayı asal değildir")
elif(asnumb==1):
    print("sayı asal değildir")
else:
    print(f"{asnumb} sayısı asal sayıdır.")'''          
#---------------------------------------------------------------------------------------------
