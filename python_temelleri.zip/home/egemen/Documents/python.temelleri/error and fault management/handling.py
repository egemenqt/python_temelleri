while True:
    try:                            #try deneme bölümüdür eğer hata gelirse except e gidilir
        x=int(input("x:"))
        y=int(input("y:"))
        rs = x/y
        print("rs:",rs.__round__(1))
    # '''except (ZeroDivisionError):                         #except yanına parantez açarak kullanıcının yanlışlıkla
    #     print("y 0 olamaz ayrıca 0/0 bölünemez")        #yapacağı hata konusunda bilinçlendirebilirsin
    # except ValueError:                                  #python built in except ile hatalara bakabilirsin
    #     print("sadece sayısal değer giriniz")           #except(a,b) iki hata tanımlanabilir
    # except:                                             #except(a,b as e) gibi tanımlanırsa hata kaydedilebilir
    #     print("bilinmeyen bir hata")  '''               #except için ayrı else bloğu yazılabilir
    except Exception as i:
        print("bilinmeyen hata oluştu")
        print(i)                                        
    else:
        break                           
#eğer while true yapıp yukarıdaki gibi tanımlarsan program doğru cevabı alana kadar sürekli döner