#faktöryel fonk oluşturup fonka gelen değer için hata mesajı verdir

#---------------------------------------------------------
#girilen parola içine türkçe karakter hatası ver
psw=input("parola giriniz:")
# if(psw==)