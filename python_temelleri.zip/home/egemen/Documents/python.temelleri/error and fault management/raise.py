# x=10
# if(x>5):
#     raise ValueError("x 5 ten büyük olamaz")
#Python raise Anahtar Sözcüğü, istisnaları veya hataları yükseltmek için kullanılır.
#  raise anahtar sözcüğü bir hata oluşturur ve programın denetim akışını durdurur.
#  Geçerli özel durumu bir özel durum işleyicisinde açmak için kullanılır,
#  böylece çağrı yığınının daha yukarısında işlenebilir.
#raise komutunun en büyük olayı if ile çalışabilmesi