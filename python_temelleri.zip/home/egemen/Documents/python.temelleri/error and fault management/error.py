# try expenct komutu eğer kullanıcı girmesi gereken değerden farklı değer girerse veya hatalı değer
#girmesi durumunda yazılabilecek oldukça kullanışlı error methodlarıdır
#aşağıdaki gibi kullanılır

try:
    x=int(input("sayı 1:"))
    y=int(input("sayı 2:"))
    print(x+y)
except:
    print("bilinmeyen hata oluştu")
# burada kullanıcı sayı yerine karakter girerse veya girmemesi gereken bir ifade girerse
#expect devreye girer