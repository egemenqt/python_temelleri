'''liste = ["1","2","5a","10b","20c","10","50"]'''
#liste elemanları içindeki sayısal değeri bul
# for i in liste:
#     try:
#         print(int(i))
#     except ValueError:
#         continue
#-------------------------------------------------
#kullanıcı quit(q) değerini girmedikçe aldığımız herinputun sayı olduğundan emin olun
#aksi halde hata mesajı yazdır
'''while True:
    x=input("sayı giriniz:")
    if(x=="q"):
        break
    try:
        result = float(x)
        print(f"girilen sayı:{result.__round__(1)}")
    except ValueError:
        print("hata lütfen sayısal değer giriniz")
    else:
        break'''
#-----------------------------------------------------------
d = {"product name":"pwnagotchi"}
try:
    print(d["product name"])
except KeyError:
    print("ürün kütüphanede tanımlı değil")
