# sytnax error => yazım hatası
#name error => tanımlanmamış değişken kullanımı
#type error =>hatalı parametre kullanımı
#Index error => yanlış index numarası
#value error => hatalı tip kullanımı
#keyerror => key hatası (genelde olmayan key numarasına ulaşmak istediğimizde çıkar)
#attribute error => olmayan bir özelliğe ulaşmak istediğimizde bu hatayı alırız örneğin
"kesae".Upper()
#daha fazlası python built in expection da bulabilirsin