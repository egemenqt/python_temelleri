a,b,c=2,5,10
# numb1=int(input("bir sayı giriniz:  "))
# numb2=int(input("ikinci sayıyı giriniz: "))
# çp=numb1*numb2
# tp=(a+b+c)
# result=çp-tp
# print(result)
# c//=b
# tp%=3
# b**=a
numbs=1,5,7,10,3
a,*b,c=numbs
# c**=3
print(a,b,c)
print(b[0]+b[1]+b[2])
