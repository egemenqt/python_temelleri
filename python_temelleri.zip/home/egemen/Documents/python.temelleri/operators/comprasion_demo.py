# numb1=int(input("bir sayı giriniz:  "))
# numb2=int(input("ikinci sayıyı giriniz:     "))
# rs = numb1>numb2
# print(rs)
#-----------------------------------------------------------------------------------------
''''
numb=int(input("bir sayı giriniz:  "))
numb%=2
print("girilen sayının 2 ile bölümünden kalan: "+ str(numb))'''

#-----------------------------------------------------------------------------------------
'''num=int(input("bir sayı giriniz: "))
rs = num<0
print(f"girilen sayı negatiftir:  {rs}")'''
#-------------------------------------------------------------------------------------------
'''
vıze1=int(input("1.vize notunuzu giriniz: "))
vıze2=int(input("2.vize notunuzu giriniz: "))
fn=int(input("final notunuzu giriniz: "))
rs = ((vıze1+vıze2)/2)*0.6 + fn*0.4
avarage=(rs>=50)
print(f"{rs} ortalamalı öğrenci geçti:  {avarage} ")'''
#-----------------------------------------------------------------------------------------
maıl=input("mail adresinizi giriniz:  ")
paswrd=input("şifrenizi giriniz:  ")
rs = (maıl.strip().lower()=="egemen.y")
rs2=(paswrd.strip()=="12645")
print("email doğruluk durumu:  {}   şifre doğruluk durumu:  {}".format(rs,rs2))