x = int(input("yaşınızı giriniz:  "))
sıcıl=input("adli sicil kaydınız varmı: ")
rs= (sıcıl=="yok")
'''nmb= 18<=x<=45'''  # 5<x<15 durumu iki aralık olabilir
#--------------------------------------------------
'''nmb = (18<=x) and (x<=45) '''      # and operatörü  devam edilebilir (2+ yapılabilir)
# true and true => true
#true and false=> false
#false and false => false
#--------------------------------------------------------
#or (veya) operatörü
'''nmb = (18<=x) or (rs)'''
#true or true=> true
#true or false=> true
#false or false=>false
#--------------------------------------------------------------

# print(f"ehliyet alma durumu:  {nmb}")
