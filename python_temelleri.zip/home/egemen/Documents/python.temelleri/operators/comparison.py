a,b,c,d=5,5,20,9
# rs = (a==b)   # == komutu eşitmi diye sorar
# rs= (a!=b)    # != komutu eşit değil mi diye sorar
usernm = "egemen.yg"
passwrd= "12645"
rs = (usernm=="egemen.yg")
rs=(passwrd=="12645")
rs=(a<=b)
print(rs)     
