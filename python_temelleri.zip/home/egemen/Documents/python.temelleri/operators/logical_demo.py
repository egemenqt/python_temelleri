'''
nmb1=int(input("bir sayı giriniz: "))
rs  = 50<=nmb1 and nmb1<=100
print("sayının 50 ile 100 arasında olma durumu:     {}".format(rs))'''
#----------------------------------------------------------------------------
'''
nmb1=int(input("bir sayı giriniz: "))
rs = (nmb1>=0) and (nmb1%2==0)
print(f"sayının tek pozitif sayı olma durumu:  {rs}") '''
#---------------------------------------------------------------------------
'''
un="egemen.y"
pw="12645"
username = input("kullanıcı adınızı giriniz:  ")
passwrd= input("şifrenizi giriniz:  ")
rs = (un==username) and (pw==passwrd)
print("kullanıcının girme durumu:  {}".format(rs))'''
#--------------------------------------------------------------------------------------
'''
nmb1=int(input("1.sayı: "))
nmb2=int(input("2.sayı: "))
nmb3=int(input("3.sayı: "))
rs = (nmb1>nmb2) and (nmb1>nmb3)
rs2 = (nmb2>nmb1) and (nmb2>nmb3)
rs3 = (nmb3>nmb2) and (nmb3>nmb1)
print(f"1.sayı en büyük sayı :  {rs}")
print(f"2.sayı en büyük sayı :  {rs2}")
print(f"3.sayı en büyük sayı :  {rs3}")'''
#------------------------------------------------------------------------------------------
'''
v1= int(input("1.vize notunuzu giriniz:  "))
v2= int(input("2.vize notunuzu giriniz:  "))
fn= int(input("final notunuzu giriniz:  "))
avarage = (((v1+v2)/2)*0.6 + fn*0.4)
# rs = (avarage>=50) and (fn>=50)
rs  =   (avarage>=50)  or (fn>=70)
print(f"geçme durumu:  {rs}")'''
#----------------------------------------------------------------------------------------
weıght = float(input("kilonuzu giriniz:  "))
length = float(input("boyunuzu giriniz:  "))
hsp = (weıght/(length**2))
rs1= (0<=hsp<18.4)
rs2= (18.5<=hsp<=24.9)
rs3= (25.0<=hsp<=29.9)
print(f"zayıf olma durumu :   {rs1}")
print(f"normal  olma durumu :   {rs2}")
print(f"kilolu olma durumu :   {rs3}")
