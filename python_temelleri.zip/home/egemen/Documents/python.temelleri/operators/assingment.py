a,b,c= 110,20,30
# a+=5  # a= a+5
# a-=5    #a=a-5
# a*=5    #a=a*5
vlues= (1,2,3,4,5,6)      
*a,b,c=vlues        #  *a karakteri tanımlanan tupplenin hangi değere aktaracağını yazar
print(a,b,c)