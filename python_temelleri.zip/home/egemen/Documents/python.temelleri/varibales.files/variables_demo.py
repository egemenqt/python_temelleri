#uygulama 1
ogradi="egemen "
ogrsoyadi=" yiğit"
ogrenciab= ogradi  +  ogrsoyadi
ogrnumb="571"
ogrcin="erkek"
print("öğrenci bilgileri :"+ogrenciab)
#uygulama 2
urun1=50
urun2=60.5
urun3=356.45
print("ürün fiyat toplamı=",urun1+urun2+urun3)#virgül koyduktan sonra pc hesaplama yapabilir
