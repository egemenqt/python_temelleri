#geçici olarak veri sakladığımız alandır değişkenler
'''uruna=5000
urunb = 6000
kdv = 0.90
print(uruna+(uruna*kdv))
print(urunb+(urunb*kdv)) '''
sayi1 = 60 
# değişkenler sayı ile başlamaz = 3sayi > yanlıs tanımlama
# değişkenlerde büyük küçük harf duyarlılığı vardır (yas=YAS) eşit değildir gibi
# değişkenler sıra ile tanımlanabilirler = (a,b,c= 10,20,30) gibi
a,b,c=10,20,30
print(a,b,c) 
# altta tanımladığın tip string tipidir ve karakterleri içerir
name = "egemen"
print(type(name))
