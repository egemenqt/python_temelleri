#int sayısal değerleri tanımlar

# age=20
# print(type(age))

#float ondalıklı sayısal değerleri tanımlar
# weight=46.4
# print(type(weight))

#string karakterleri tanımlar (kelimeler , harfler vb)
# name="ahmet"
# print(type(name))

#bool doğrumu değilmi olarak tanımlar
# isStudent=True
# print(type(isStudent))

#input kullanıcıdan veri girmesini ister ve veri tipi daima string olarak tanımlar fakat değiştirilebilir
'''
x = int(input("bir sayı giriniz:  "))
y = int(input("ikinci sayıyı giriniz: "))
print("sayıların toplamı: ", x+y)
'''
#değişkenler birbirine değiştirilebilirler örneğin:

#int to float
from operator import truediv

''''
numb=30
result=float(numb)
print(type(result))'''

#bool to str
'''''
isogr=True
result = str(isogr)
print(type(result))'''''

#true == 1 false== 0 yazar
''''
hage=True
rs=int(hage)
print(rs)'''

