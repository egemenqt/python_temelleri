#uygulama   dairenin alanı ve çevresini kullanıcıdan veri isteyerek hesaplama

'''
yarıcap=int(input("dairenin yarıçapını giriniz: "))
pi=3.14
chamberc=2*pi*yarıcap

charmbera=pi*(yarıcap**2)
print("dairenin çevresi: ",chamberc)
print("dairenin alanı: ",charmbera)'''

#bir aracın km den gitti yolu mil cinsinden yaz

km=int(input("kaç km yol aldınız:  "))
mıl=km/1.609344
mıl=round(mıl,2)                                #round yuvarlama işlemini yapar atadığınız değişkene virgülden sonra kaç basamak ekranda yazsın istiyorsanız onu yazar
print("gidilen yol mil cinsinden:  ",mıl)

