    #filter() filter(function, iterable) : filter fonksiyonu parametre olarak fonksiyon ve liste, 
# demet gibi döngüye sokulabilecek veri alır. Geriye true koşulunu sağlayan değerleri döndürür
# ages = [1,9,15,22,54,62,27]
'''def funcage(x):
    if x>18:
        return True
    else:
        return False
rs = list(filter(funcage,ages))
print(rs)'''
#--------------------------------------------
# rs = list(filter(lambda x:x<18,ages))       #üstteki işlem tek satırda yapılabilir 
# print(rs) #filter kullanma   = list(filter(yapacağımız işlemdeki fonk veya lambda ile işlem/,alacağımız list değeri))
#--------------------------------------------
isimler = ["ali","osman","samet","egemen","enes"]
'''rs = list(filter(lambda x:x[0]=="e",isimler))''' #değişiklik yapmak için map ifadesini kullan
fılterresult = filter(lambda x:x[0]=="e",isimler)
result = list(map(lambda x:x.capitalize(),fılterresult))
rs = [i.capitalize() for i in isimler if(i[0]=="e")]
print(result)
print(rs)
ıst = [1,25,45,678,124,5731]
rs1 = list(filter(lambda x:x>=400,ıst)  )
print(rs1)  