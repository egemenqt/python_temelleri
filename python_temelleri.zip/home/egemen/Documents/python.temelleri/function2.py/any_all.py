# and komutu ile any komutu benzerdir
rs = any([True,False,True]) #bu durumda bize true değerini verir anyde sadece bi tane true değer olması yeterlidir
rs2 =all([True,False,True])   #all komutunda true değer dönmesi için tümünün true olması lazım
print(rs)               
print(rs2)                      #any([]) şeklinde kullanılır
                                #all([]) şeklinde kullanılır
