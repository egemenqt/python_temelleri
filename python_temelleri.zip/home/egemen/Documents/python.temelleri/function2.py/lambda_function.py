'''def timoty(a):               lambdalar birden fazla parametre kabul eder ama tek satırda tek işlem yaparlar
    return    a**2
print(timoty(5))'''
# bu işlemi tek satırda yapmamılı lambda komutu sağlar
'''result = lambda x:x**2
print(result(5))
rs2=lambda a,b,c: a*b-c #lambda işleminde birden fazla variable atanabilir
print(rs2(1,2,5))'''
# isimsiz  bir değişkeni fonk içinde kullanmak için lambda kullanılır aşağıdaki gibi
'''def func(n):
    return lambda x:x*n
timoty = func(10)
timoty2 = func(30)
timoty3 = func(20)
rs = timoty(2)
rs = timoty2(3)
rs = timoty3(4)
print(rs)
print(rs)
print(rs)'''
#lambda illaki lazım değil ama kısa ve kullanışlı