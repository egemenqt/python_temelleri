#min max sayısal veya alfabetik olarak en fazla ve en az bulunur
names = ["ali","egemen","enes","samet","ziya","yiğit"]
rs = min([len(nm) for nm in names])     #burada yapmış olduğumuz en az karaktere sahip ismin karakter
print(rs)                               #sayısını yazdırmak
#eğer ismi yazdırmak istersek
rs = max(names,key=lambda nm:len(nm))       #burada min key'e karşılık gelen ismi yazdırır
print(rs)
products = [
    {"phone":"iphone x","price":5000},
    {"phone":"iphone xr","price":7000},
    {"phone":"iphone 11","price":9000},
]
result = min(products,key=lambda paha:paha["price"]) #soldaki gibi dictionarydeki bilgileri max min 
print(result)                                          # olarak bulabiliriz
