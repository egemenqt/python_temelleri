#sorted sıralama işlemi yapar sort() methodundan en büyük farkı orijinal list sorted()'da değişmez
numbs = [1,25,47,895,356,2,5]
# numbs.sort()
rs = sorted(numbs)
#-----------------------------------------------------
rs2 = sorted(numbs,reverse=True) #soldaki kullanım gibi yapılırsa reverse=true olduğu için ters sıralar
print(rs)
print(rs2)
userınfo=[
    {"name":"egemen","surname":"yiğit"},
    {"name":"samet","surname":"ayaz"},
    {"name":"enes","surname":"özdemir"}
]
rs = sorted(userınfo,key=len)
rs = sorted(userınfo,key= lambda nm:nm["name"])
print(rs)