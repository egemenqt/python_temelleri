#map metodu liste üzerinde belli kuralı uygulamak için kullanılır
numbs=[6,7,8,91]
'''us=[]
for i in numb:
    a=i**2
    us.append(a)
print(us)'''
#aynı işlemş aşağıdaki gibide yapabilirdik
# def usal(num):
    # return num**2
# rs=list(map(usal,numbs))# görüldüğü gibi list olarak tanımlamalısın   /map(fonksiyonu yaz,lıst ifadesini yaz)/
# print(rs)
'''rs=list(map(lambda x:x**2,numbs)) # tek satırda lambda yarıdımı ile yazılabilir
print(rs)
sayilar=["1","2","3","4","8"]       #sayıları str ifadeden inte çevirebiliriz
rs = list(map(int,sayilar))'''
'''names =["ali","osman","ayşe","deniz"]
rs = list(map(str.capitalize,names))
print(rs)'''
#Python Map fonksiyonu nedir?
#map() Fonksiyonu: Parametre olarak aldığı fonksiyona, parametre olarak aldığı 
# listenin her elemanını sırasıyla parametre olarak gönderir. 
# Tek bir liste için kullanmak zorunda değilsiniz. Birden fazla liste için uygulanabilir
#map listede değişiklik yapmak için birebirdir