# sum komutu lisete içine veya dictionary içine tanımlanan sayıları toplar
numbs = [10,20,30,40,50]
rs = sum(numbs,20)         #sum(numbs,10) gibi işlemde toplama 10 daha eklenir sadece 2 argüman ekleyebilirsin
print(rs)
products = [
    {"phone":"iphone x","price":5000},
    {"phone":"iphone xr","price":7000},
    {"phone":"iphone 11","price":9000},
    {"phone":"iphone 11","price":0},

]
rs2 =sum([i["price"] for i in products] )
prıcetotal=sum([i["price"] for i in products if i["price"]!=0])
print(rs2)